export const BACKEND_URL = "https://neurowatch-production.up.railway.app";
